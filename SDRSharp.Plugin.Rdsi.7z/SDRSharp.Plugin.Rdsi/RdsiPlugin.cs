﻿using SDRSharp.Common;
using SDRSharp.Radio;
using System.Windows.Forms;

namespace SDRSharp.Plugin.Rdsi
{
    public class RdsiPlugin : ISharpPlugin, ICanLazyLoadGui, IMustLoadGui, ISupportStatus
    {
        private const string _displayName = "RDS";
        private ISharpControl _controlInterface;
        private RdsiPluginPanel _configGui;

        public string DisplayName
        {
            get { return _displayName; }
        }

        public UserControl Gui
        {
            get
            {
                LoadGui();
                return _configGui;
            }
        }

        public void Close()
        {
        }

        public bool IsActive => true;

        public bool LoadNeeded => true;

        public void Initialize(ISharpControl control)
        {
            _controlInterface = control;
            _configGui = new RdsiPluginPanel(_controlInterface);
            control.RegisterStreamHook((object)new RdsHwnd(_configGui), ProcessorType.RDSBitStream);
        }

        public void LoadGui()
        {
            if (_configGui == null)
            {
                _configGui = new RdsiPluginPanel(_controlInterface);
            }
        }
    }
}
