﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Diagnostics;
using SDRSharp.Common;

namespace SDRSharp.Plugin.Rdsi
{
    public partial class RdsiPluginPanel : UserControl
    {
        private bool _processRDS = false;
        private readonly ISharpControl _control;
        private FileStream _fs = null;

        public RdsiPluginPanel(ISharpControl control)
        {
            InitializeComponent();
            _control = control;
            labelPicode.Text = "";
            labelRdsText.Text = "";
            labelGrp.Text = "";
            textBoxLogFile.Text = "";
        }

        public void WriteToFile(String groups, String picode)
        {
            if (_processRDS)
            {
                if (_fs != null)
                {
                    byte[] fsData = Encoding.ASCII.GetBytes(groups);
                    _fs.Write(fsData, 0, fsData.Length);
                }
            }
            labelPicode.Text = picode + " " + _control.RdsProgramService;
            //labelRdsText.Text = _control.RdsRadioText;
            //labelGrp.Text = groups.TrimEnd('\r', '\n'); 
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            _processRDS = false;
            textBoxLogFile.Text = "";
            labelPicode.Text = "";
            labelRdsText.Text = "";
            labelGrp.Text = "";
            if (_fs == null)
            {
                String lf = Application.StartupPath + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") +
                "_" + _control.Frequency.ToString() + ".spy";
                try
                {
                    _fs = new FileStream(lf, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                }
                catch (IOException ex)
                {
                    textBoxLogFile.Text = ex.Message;
                    return;
                }
                textBoxLogFile.Text = lf;
                _processRDS = true;
            }
            buttonStart.Enabled = false;
            buttonStop.Enabled = true;
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            _processRDS = false;
            labelPicode.Text = "";
            labelRdsText.Text = "";
            textBoxLogFile.Text = "";
            labelGrp.Text = "";
            _fs.Flush();
            _fs.Close();
            _fs.Dispose();
            _fs = null;
            buttonStop.Enabled = false;
            buttonStart.Enabled = true;
        }

        public void Close()
        {
            _processRDS = false;
            if (_fs != null)
            {
                _fs.Flush();
                _fs.Close();
            }
        }

    }
}
