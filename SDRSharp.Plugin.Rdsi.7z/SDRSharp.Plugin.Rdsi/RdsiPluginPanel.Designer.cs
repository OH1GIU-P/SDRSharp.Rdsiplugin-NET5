﻿namespace SDRSharp.Plugin.Rdsi
{
    partial class RdsiPluginPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.labelPicode = new System.Windows.Forms.Label();
            this.textBoxLogFile = new System.Windows.Forms.TextBox();
            this.labelRdsText = new System.Windows.Forms.Label();
            this.labelGrp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(10, 10);
            this.buttonStart.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(88, 27);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Location = new System.Drawing.Point(128, 10);
            this.buttonStop.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(88, 27);
            this.buttonStop.TabIndex = 1;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // labelPicode
            // 
            this.labelPicode.AutoSize = true;
            this.labelPicode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelPicode.ForeColor = System.Drawing.Color.Green;
            this.labelPicode.Location = new System.Drawing.Point(13, 45);
            this.labelPicode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPicode.Name = "labelPicode";
            this.labelPicode.Size = new System.Drawing.Size(27, 13);
            this.labelPicode.TabIndex = 2;
            this.labelPicode.Text = "PIC";
            // 
            // textBoxLogFile
            // 
            this.textBoxLogFile.Location = new System.Drawing.Point(10, 113);
            this.textBoxLogFile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBoxLogFile.Multiline = true;
            this.textBoxLogFile.Name = "textBoxLogFile";
            this.textBoxLogFile.ReadOnly = true;
            this.textBoxLogFile.Size = new System.Drawing.Size(205, 78);
            this.textBoxLogFile.TabIndex = 3;
            // 
            // labelRdsText
            // 
            this.labelRdsText.AutoSize = true;
            this.labelRdsText.Location = new System.Drawing.Point(13, 67);
            this.labelRdsText.Name = "labelRdsText";
            this.labelRdsText.Size = new System.Drawing.Size(32, 15);
            this.labelRdsText.TabIndex = 4;
            this.labelRdsText.Text = "TEXT";
            // 
            // labelGrp
            // 
            this.labelGrp.AutoSize = true;
            this.labelGrp.Location = new System.Drawing.Point(13, 90);
            this.labelGrp.Name = "labelGrp";
            this.labelGrp.Size = new System.Drawing.Size(26, 15);
            this.labelGrp.TabIndex = 5;
            this.labelGrp.Text = "Grp";
            // 
            // RdsiPluginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.labelGrp);
            this.Controls.Add(this.labelRdsText);
            this.Controls.Add(this.textBoxLogFile);
            this.Controls.Add(this.labelPicode);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "RdsiPluginPanel";
            this.Size = new System.Drawing.Size(238, 216);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Label labelPicode;
        private System.Windows.Forms.TextBox textBoxLogFile;
        private System.Windows.Forms.Label labelRdsText;
        private System.Windows.Forms.Label labelGrp;
    }
}
